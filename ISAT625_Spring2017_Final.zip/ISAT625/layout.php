<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}
?>


<html>
<head>
<title>ADVOP</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="style.css">
</head>
<body>
<!-- Save for Web Slices (layout.psd) -->
<table class="center" id="Table_01" width="1024" height="769" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="12">
			<img src="images/layout_01.gif" width="1024" height="95" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="images/layout_02.gif" width="11" height="33" alt=""></td>
		<td>
			<a href="home.html" target="bodyframe">
				<img src="images/homebutton.gif" width="140" height="23" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/layout_04.gif" width="14" height="33" alt=""></td>
		<td>
			<a href="advisement.php" target="bodyframe">
				<img src="images/advisingbutton.gif" width="166" height="23" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/layout_06.gif" width="10" height="33" alt=""></td>
		<td>
			<a href="studentactions.html" target="bodyframe">
				<img src="images/studentactionsbutton.gif" width="278" height="23" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/layout_08.gif" width="13" height="33" alt=""></td>
		<td>
			<a href="adminactions.html" target="bodyframe">
				<img src="images/adminactionsbutton.gif" width="238" height="23" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/layout_10.gif" width="13" height="33" alt=""></td>
		<td colspan="2">
			<a href="about.html" target="bodyframe">
				<img src="images/aboutbutton.gif" width="131" height="23" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/layout_12.gif" width="10" height="33" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/layout_13.gif" width="140" height="10" alt=""></td>
		<td>
			<img src="images/layout_14.gif" width="166" height="10" alt=""></td>
		<td>
			<img src="images/layout_15.gif" width="278" height="10" alt=""></td>
		<td>
			<img src="images/layout_16.gif" width="238" height="10" alt=""></td>
		<td colspan="2">
			<img src="images/layout_17.gif" width="131" height="10" alt=""></td>
	</tr>
	<tr>
		<td colspan="10">
			<img src="images/layout_18.gif" width="895" height="25" alt=""></td>
		<td>
			<a href="logout.php">
				<img src="images/logoutbutton.gif" width="119" height="25" alt=""></a></td>
		<td>
			<img src="images/layout_20.gif" width="10" height="25" alt=""></td>
	</tr>
	<tr>
		<td colspan="12">
			<img src="images/layout_21.gif" width="1024" height="11" alt=""></td>
	</tr>
	<tr>
		<td rowspan="4" valign="top">
			<img src="images/layout_22.gif" width="11" height="604" alt=""></td>
		<td height="31" colspan="10">
			<iframe height="30" width="1003" name="tickerframe" src="ticker.html" scrolling="no" frameborder="0"></iframe></td>
		<td rowspan="4" valign="top">
			<img src="images/layout_24.gif" width="10" height="604" alt=""></td>
	</tr>
	<tr>
		<td colspan="10">
			<img src="images/layout_25.gif" width="1003" height="5" alt=""></td>
	</tr>
	<tr>
		<td height="558" colspan="10">
	  <iframe height="558" width="1003" src="home.html" name="bodyframe" frameborder="0" class="bodyframe"></iframe></td>
	</tr>
	<tr>
		<td colspan="10">
			<img src="images/layout_27.gif" width="1003" height="10" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="140" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="166" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="10" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="278" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="13" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="238" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="13" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="12" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="119" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="10" height="1" alt=""></td>
	</tr>
</table>
<center>
Presented by:<p>
<a href="mailto:nibha.manandhar@selu.edu?Subject=Hello,%20ADVOP" >Nibha Manandhar</a>
,
<a href="mailto:dmytro.obolenskyi@selu.edu?Subject=Hello,%20ADVOP" >Dmytro Obolenskyi</a>
 ,
<a href="mailto:kari.shelton@selu.edu?Subject=Hello,%20ADVOP" >Kari Shelton</a>
,
<a href="mailto:chad.sziszak@selu.edu?Subject=Hello,%20ADVOP" >Chad Sziszak</a>
</p>
</center>

<!-- End Save for Web Slices -->
</body>
</html>
