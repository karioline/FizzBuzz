<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}
?>


<html>
<head>
<title>concentrations</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<style>

table.center {
		margin-left:auto;
		margin-right:auto;
	}
body {
	background-color: #1C7543;
	}

</style>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- Save for Web Slices (concentrations.psd) -->
<table class="center" id="Table_01" width="1280" height="1024" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="7">
			<img src="images/concentrations_01.gif" width="1280" height="485" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="images/concentrations_02.gif" width="246" height="539" alt=""></td>
		<td>
			<a href="premba.php">
				<img src="images/premba.gif" width="201" height="37" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/concentrations_04.gif" width="93" height="539" alt=""></td>
		<td>
			<a href="scientific.php">
				<img src="images/scientific.gif" width="203" height="37" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/concentrations_06.gif" width="95" height="539" alt=""></td>
		<td>
			<a href="infotech.php">
				<img src="images/infotech.gif" width="203" height="37" border="0" alt=""></a></td>
		<td rowspan="2">
			<img src="images/concentrations_08.gif" width="239" height="539" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/concentrations_09.gif" width="201" height="502" alt=""></td>
		<td>
			<img src="images/concentrations_10.gif" width="203" height="502" alt=""></td>
		<td>
			<img src="images/concentrations_11.gif" width="203" height="502" alt=""></td>
	</tr>
</table>
<!-- End Save for Web Slices -->
</body>
</html>
