<?PHP
require_once("./include/membersite_config.php");

if(isset($_POST['submitted']))
{
   if($fgmembersite->Login())
   {
        $fgmembersite->RedirectToURL("layout.php");
   }
}

?>
<!DOCTYPE html PUBLIC >
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Login</title>
      <style>
          input[type="text"]{
              background-image: url('logimages/username.gif');
              height: 27px;
              width: 388px;
      				text-align: center;
          }
      		input[type="password"]{
              background-image: url('logimages/username.gif');
              height: 27px;
              width: 388px;
      				text-align: center;
          }
      		table.center {
      	 			margin-left:auto;
      	 			margin-right:auto;
       		}
      		body {
          background-color: #1C7543;
      }
      </style>

      <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>
</head>
<body>
  <table class="center" id="Table_01" width="1280" height="1024" border="0" cellpadding="0" cellspacing="0">
  	<tr>
  		<td colspan="5">
  			<img src="loginimages/login_01.gif" width="1280" height="445" alt=""></td>
  	</tr>
  	<tr>
  		<td rowspan="6">
  			<img src="loginimages/login_02.gif" width="470" height="579" alt=""></td>
  		<td colspan="3">
<form id='login' action='<?php echo $fgmembersite->GetSelfScript(); ?>' method='post' accept-charset='UTF-8'>
<input type='hidden' name='submitted' id='submitted' value='1'/>
    <input type='text' name='username' id='username' value='<?php echo $fgmembersite->SafeDisplay('username') ?>' maxlength="50" /><br/>
    <span id='login_username_errorloc' class='error'></span></td>
    		<td rowspan="6">
    			<img src="loginimages/login_04.gif" width="422" height="579" alt=""></td>
    	</tr>
    	<tr>
    		<td colspan="3">
    			<img src="loginimages/login_05.gif" width="388" height="38" alt=""></td>
    	</tr>
    	<tr>
    		<td colspan="3">
    <input type='password' name='password' id='password' maxlength="50" /><br/>
    <span id='login_password_errorloc' class='error'></span>
  </td>
  </tr>
  <tr>
  <td colspan="3">
  <img src="loginimages/login_07.gif" width="388" height="140" alt=""></td>
  </tr>
  <tr>
  <td rowspan="2">
  <img src="loginimages/login_08.gif" width="91" height="330" alt=""></td>
  <td><input type="image" src="loginimages/button.gif" value="submit" alt="Submit Form" /></form></td>
  <td rowspan="2">
    <img src="loginimages/login_10.gif" width="94" height="330" alt=""></td>
</tr>
<tr>
  <td>
    <img src="loginimages/login_11.gif" width="203" height="293" alt=""></td>
</tr>
</table>
<div class='short_explanation'><a href='reset-pwd-req.php'>Forgot Password?</a></div>
</form>
<!-- client-side Form Validations:
Uses the excellent form validation script from JavaScript-coder.com-->

<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("login");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("username","req","Please provide your username");

    frmvalidator.addValidation("password","req","Please provide the password");

// ]]>
</script>
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->

</body>
</html>
