<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}
?>

<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
    $studentLookup = $link->query("select wNumber,studentName from students order by studentName");
?>


<html>
<head>
<title>Scientific Concentration Advisement Form</title>

      <style type="text/css">
      body {background-color: #006633}
      .tg  {border-collapse:collapse;border-spacing:0;margin-left:auto;margin-right:auto;}
      .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-width:1px;overflow:hidden;word-break:normal;}
      .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-width:1px;overflow:hidden;word-break:normal;}
      .tg .tg-fyhu{background-color:#ffff00;color:#ffffff;text-align:center;border-style:hidden;vertical-align:top}
      .tg .tg-o6jj{background-color:#006633;color:#ffffff;text-align:center;border-color: #ffff00;border-style: solid hidden solid hidden;vertical-align:top}
      input.courses {
          height: 40px;
          width: 150px;
          background-color: #006633;
          border-style: inset;
         border-width: 1px;
      }
      label {
  		color: white;
  	}

      </style>
<body>

    <?php

      if (isset($_POST['submit'])) {
        $studentID = $_POST['wNumber'];
      }
      else {
         $studentID = "";
      }
    ?>

      <form action="" method="post">
      <label for="wNumber">Select a student:</label><br />
      <select name="wNumber" id="wNumber">
        <option label=" " value=""><?php echo 'You are advising:' . $studentID; ?>
            <?php
            while ($row = $studentLookup->fetch_assoc()) {

                            unset($wNumber,$studentName);
                            $wNumber = $row['wNumber'];
                            $studentName = $row['studentName'];
                            echo '<option value="'.$wNumber.'">'.$wNumber.' - '.$studentName.'</option>';
          }

          ?>
            </select>
            <input name="submit" type="submit" />
      </form>

      <table class="tg" style="undefined;table-layout: fixed; width: 623px">
      <colgroup>
      <col style="width: 110px">
      <col style="width: 185px">
      <col style="width: 21px">
      <col style="width: 110px">
      <col style="width: 185px">
      <col style="width: 21px">
      <col style="width: 110px">
      <col style="width: 185px">
      </colgroup>
        <tr>
          <th class="tg-o6jj">CMPS120<br /><input type="submit"value="Check" /></th>
          <th class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS120" /></th>
          <th class="tg-fyhu"></th>
          <th class="tg-o6jj">MATH155 or MATH161</th>
          <th class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH155" /></th>
          <th class="tg-fyhu"></th>
          <th class="tg-o6jj">MATH165</th>
          <th class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH165" /></th>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS161</td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS161" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH200</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH201</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS257</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH241</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH380</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS280</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS285</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS290</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS293</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS294</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS309</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS315</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS375</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS383</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS389</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS390</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS391</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS394</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS401</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS409</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS411</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS415</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS420</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS431</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS434</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS439</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS441</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS443</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS447</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS450</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS455</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS458</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS460</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS470</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS479</td>
          <td class="tg-o6jj">text field</td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS482</td>
          <td class="tg-o6jj">text field</td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj"></td>
          <td class="tg-o6jj"></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj"></td>
          <td class="tg-o6jj"></td>
        </tr>
      </table>
    </body>
    </html>
