<?PHP
 require_once("./include/membersite_config.php");

 if(!$fgmembersite->CheckLogin())
	 {
		$fgmembersite->RedirectToURL("login.php");
		exit;
		 }
	?>

<html>
<head>
<title>Advisement sheet selection</title>
<link rel="stylesheet" type="text/css" href="subpages.css" />
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<h3> Which concentration would you like to advise a student in?</h3>

			<a href="premba.php">
				<img src="images/premba.gif" width="201" height="37" border="0" alt=""></a>
	<br />
	<br />
			<a href="scientific.php">
				<img src="images/scientific.gif" width="203" height="37" border="0" alt=""></a>
<br />
<br />
			<a href="infotech.php">
				<img src="images/infotech.gif" width="203" height="37" border="0" alt=""></a>

</body>
</html>
