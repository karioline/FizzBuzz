<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}
?>

<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
    $studentLookup = $link->query("select wNumber,studentName from students order by studentName");
    $studentLookup2 = $link->query("select wNumber,studentName from students order by studentName");

  ?>


<html>
<head>
<title>Scientific Concentration Advisement Form</title>

      <style type="text/css">
      body {background-color: #006633}
      .tg  {border-collapse:collapse;border-spacing:0;margin-left:auto;margin-right:auto;}
      .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-width:1px;overflow:hidden;word-break:normal;}
      .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-width:1px;overflow:hidden;word-break:normal;}
      .tg .tg-fyhu{background-color:#ffff00;color:#ffffff;text-align:center;border-style:hidden;vertical-align:top}
      .tg .tg-o6jj{background-color:#006633;color:#ffffff;text-align:center;border-color: #ffff00;border-style: solid hidden solid hidden;vertical-align:top}
      .courses {
          height: 40px;
          width: 150px;
          background-color: #006633;
          border-style: inset;
         border-width: 1px;
         color: #ffffff;
      }
      label {
  		color: white;
  	}

      </style>
<body>




      <label for="wNumber">Select a student:</label><br />
      <form action="" method="post">
        <?php

          if (isset($_POST['submit'])) {
            $studentID = $_POST['wNumber'];
          }

        ?>
      <select name="wNumber" id="wNumber">
        <option label=" " value=""><?php echo 'You are advising:' . $studentID; ?></option>
            <?php
            while ($row = $studentLookup->fetch_assoc()) {

                            unset($wNumber,$studentName);
                            $wNumber = $row['wNumber'];
                            $studentName = $row['studentName'];
                            echo '<option value="'.$wNumber.'">'.$wNumber.' - '.$studentName.'</option>';
          }

          ?>
            </select>
            <input name="submit" type="submit" />
      </form>

      <table class="tg" style="undefined;table-layout: fixed; width: 623px">
      <colgroup>
      <col style="width: 110px">
      <col style="width: 185px">
      <col style="width: 21px">
      <col style="width: 110px">
      <col style="width: 185px">
      <col style="width: 21px">
      <col style="width: 110px">
      <col style="width: 185px">
      </colgroup>
        <tr>
          <th class="tg-o6jj">CMPS120<br /><input type="submit" value="Check" /></th>
          <th class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS120" /></th>
          <th class="tg-fyhu"></th>
          <th class="tg-o6jj">MATH155 or MATH161<br /><input type="submit" value="Check" /></th>
          <th class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH155" /></th>
          <th class="tg-fyhu"></th>
          <th class="tg-o6jj">MATH165<br /><input type="submit" value="Check" /></th>
          <th class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH165" /></th>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS161<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS161" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH200<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH200" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH201<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH201" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS257<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS257" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH241<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH241" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">MATH380<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="MATH380" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS280<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS280" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS285<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS285" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS290<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS290" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS293<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS293" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS294<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS294" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS309<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS309" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS315<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS315" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS375<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS375" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS383<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS383" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS389<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS389" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS390<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS390" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS391<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS391" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS394<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS394" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS401<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS401" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS409<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS409" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS411<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS411" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS415<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS415" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS420<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS420" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS431<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS431" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS434<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS434" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS439<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS439" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS441<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS441" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS443<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS443" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS447<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS447" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS450<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS450" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS455<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS455" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS458<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS458" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS460<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS460" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS470<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS470" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj">CMPS479<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS479" /></td>
        </tr>
        <tr>
          <td class="tg-o6jj">CMPS482<br /><input type="submit" value="Check" /></td>
          <td class="tg-o6jj"><input type='text' pattern='[a-zA-Z0-9]+' class="courses" name="CMPS482" /></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj"></td>
          <td class="tg-o6jj"></td>
          <td class="tg-fyhu"></td>
          <td class="tg-o6jj"></td>
          <td class="tg-o6jj"></td>
        </tr>
      </table>
    </body>
    </html>
