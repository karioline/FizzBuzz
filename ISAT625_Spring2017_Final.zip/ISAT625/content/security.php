<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


    $result = $link->query("select name from fgusers3");
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="subpages.css" />
    <title>Set User Security Level</title>
</head>

<body>

    <form action="setsecuritylevel.php" method="post">
        <p>
            <label for="name">User's Name:</label>
            <select name="name" id="name">
            <option label=" "></option>
            <?php
            while ($row = $result->fetch_assoc()) {

                            unset($name);
                            $name = $row['name'];
                            echo '<option value="'.$name.'">'.$name.'</option>';
          }

          ?>
            </select>
        </p>
        <p>
            <label for="securityLevel">Security Level:</label><br />
            <select name="securityLevel" id="securityLevel">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
            </select>
        </p>
        <input type="submit" value="Submit">

    </form>

</body>
</html>
