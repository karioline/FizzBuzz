<!doctype html>
<html>
	<head>
		<title>Delete User Data</title>
	</head>

	<?php
	$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

	// Check connection
	if($link === false){
	    die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	$userLookup = $link->query("select name,username from fgusers3 order by name");
?>


<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Remove a user.</title>
	<link rel="stylesheet" type="text/css" href="subpages.css" />
</head>

<body>

	<form action="deleteuser.php" method="post">
			<p>
					<label for="username">User:</label><br />
					<select name="username" id="username">
						<option label=" " value = "">---Name - Username---</option>
								<?php
								while ($row = $userLookup->fetch_assoc()) {

																unset($name,$username);
																$name = $row['name'];
																$username = $row['username'];
																echo '<option value="'.$username.'">'.$name.' - '.$username.'</option>';
							}

							?>
								</select>
			</p>

<input type="submit" value="Submit" />
</form>

   </body>
   </html>
