<!DOCTYPE html>



<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


  $studentLookup = $link->query("select wNumber,studentName from students order by studentName");
?>



<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="subpages.css" />
    <title>Change a student's concentration.</title>
</head>

<body>

    <form action="addToConcentration.php" method="post">
<p>
    <label for="studentName">Which student would you like to assign to a concentration?<label><br />
      <select name="wNumber" id="wNumber">
        <option label=" "></option>
            <?php
            while ($row = $studentLookup->fetch_assoc()) {

                            unset($wNumber,$studentName);
                            $wNumber = $row['wNumber'];
                            $studentName = $row['studentName'];
                            echo '<option value="'.$wNumber.'">'.$wNumber.' - '.$studentName.'</option>';
          }

          ?>
            </select>
  </p>
  <p>
    <label for="concentration">Which concentration have they chosen?</label><br />
    <select name="concentration" id="concentration">
      <option value="None Chosen">None Chosen</option>
      <option value="Scientific">Scientific</option>
      <option value="Pre-MBA">Pre-MBA</option>
<option value="Engineering">Engineering</option>
<option value="Industrial Technology">Industrial Technology</option>
    </select>
  </p>

<input type="submit" value="Submit" />

    </form>







</body>
</html>
