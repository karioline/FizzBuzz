<!doctype html>
<html>
	<head>
		<title>Delete Student Data</title>
	</head>

	<?php
	$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

	// Check connection
	if($link === false){
	    die("ERROR: Could not connect. " . mysqli_connect_error());
	}
		$studentLookup = $link->query("select wNumber,studentName from students order by studentName");
	?>


	<html lang="en">
	<head>
	    <meta charset="UTF-8">
	    <title>Delete a student.</title>
	    <link rel="stylesheet" type="text/css" href="subpages.css" />
	</head>

	<body>

	    <form action="deletestudent.php" method="post">
	        <p>
	            <label for="wNumber">Which student would you like to remove?</label><br />
	            <select name="wNumber" id="wNumber">
								<option label=" "></option>
	                  <?php
	                  while ($row = $studentLookup->fetch_assoc()) {

	                                  unset($wNumber,$studentName);
	                                  $wNumber = $row['wNumber'];
	                                  $studentName = $row['studentName'];
	                                  echo '<option value="'.$wNumber.'">'.$wNumber.' - '.$studentName.'</option>';
	                }

	                ?>
	                  </select>
 </p>

<input type="submit" value="Submit" />
</form>

   </body>
   </html>
