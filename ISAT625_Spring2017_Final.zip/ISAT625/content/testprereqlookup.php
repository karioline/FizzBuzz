<!doctype html>
<html>
	<head>
		<title>test</title>
	</head>

	<?php
	$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

	// Check connection
	if($link === false){
	    die("ERROR: Could not connect. " . mysqli_connect_error());
	}
		$courseLookup = $link->query("select distinct courseID from courses order by courseID ");
		$studentLookup = $link->query("select wNumber,studentName from students order by studentName");
	?>


	<html lang="en">
	<head>
	    <meta charset="UTF-8">
	    <title>test lookup stuff</title>
	    <link rel="stylesheet" type="text/css" href="subpages.css" />
	</head>

	<body>
		<form action="testlookup.php" method="post">
				<p>
						<label for="wNumber">Student:</label><br />
						<select name="wNumber" id="wNumber">
									<?php
									while ($row = $studentLookup->fetch_assoc()) {

																	unset($wNumber,$studentName);
																	$wNumber = $row['wNumber'];
																	$studentName = $row['studentName'];
																	echo '<option value="'.$wNumber.'">'.$wNumber.' - '.$studentName.'</option>';
								}

								?>
									</select>
				</p>

					<p>
						<label for="courseID">Course ID:</label><br />
						<select name="courseID" id="courseID">
									<?php
									while ($row1 = $courseLookup->fetch_assoc()) {

																	unset($courseID);
																	$courseID = $row1['courseID'];
																	echo '<option value="'.$courseID.'">'.$courseID.'</option>';
								}

								?>
									</select>
				</p>
					<input type="submit" value="Submit">
</form>
   </body>
   </html>
