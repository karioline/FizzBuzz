<!DOCTYPE html>

<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


    $result = $link->query("select distinct courseID from courses");
    $result2 = $link->query("select distinct courseID from courses");
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Course Record Form</title>
    <link rel="stylesheet" type="text/css" href="subpages.css" />
</head>

<body>

    <form action="insertcourse.php" method="post">
        <p>
            <label for="courseID">Course ID (ex: CMPS101):</label>
            <input type="text" name="courseID" id="courseID">
        </p>

        <p>
            <label for="courseName">Full Course Name:</label>
            <input type="text" name="courseName" id="courseName">
        </p>

        <p>
            <label for="hours">hours:</label>
            <select name="hours" id="hours">
              <option value="1">
              1
              </option>
              <option value="2">
              2
              </option>
              <option value="3">
              3
              </option>
	      <option value="4">
		4
	      </option>
		<option value="5">
		5
		</option>
		<option value="6">
		6
		</option>
            </select>
        </p>

        <p>
            <label for="sections">How many sections?:</label>
            <select name="sections" id="sections">
              <option value="1">
              1
              </option>
              <option value="2">
              2
              </option>
              <option value="3">
              3
              </option>
	      <option value="4">
		4
	      </option>
            </select>
        </p>

        <p>
            <label for="hasPrereq">Does it have a prereq?:</label>
            <select name="hasPrereq" id="hasPrereq">
              <option value="no">
              No
              </option>
              <option value="yes">
              Yes
              </option>
            </select>
        </p>

        <p>
            <label for="specialPermission">Allow department head permission to enroll?:</label>
            <select name="specialPermission" id="specialPermission">
              <option value="no">
              no
              </option>
              <option value="yes">
              yes
              </option>
            </select>
        </p>

        <p>
            <label for="prereqOf">What course is this a prereq of?:</label>
            <select name="prereqOf" id="prereqOf">
              <option label=" "></option>
            <?php
            while ($row = $result->fetch_assoc()) {

                            unset($prereqID);
                            $prereqID = $row['courseID'];
                            echo '<option value="'.$prereqID.'">'.$prereqID.'</option>';
          }

          ?>
            </select>
        </p>

        <p>
            <label for="coreqOf">What course is this a coreq of?:</label>
            <select name="coreqOf" id="coreqOf">
              <option label=" "></option>
            <?php
            while ($row = $result2->fetch_assoc()) {

                            unset($coreqID);
                            $coreqID = $row['courseID'];
                            echo '<option value="'.$coreqID.'">'.$coreqID.'</option>';
          }

          ?>
            </select>
        </p>



        <input type="submit" value="Submit">

    </form>

</body>
</html>
