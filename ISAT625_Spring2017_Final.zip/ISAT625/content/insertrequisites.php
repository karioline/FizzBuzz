    <?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $courseID = $_REQUEST['courseID'];
    $prereq = $_REQUEST['prereq'];
    $coreq = $_REQUEST['coreq'];

    // prepare and bind
    $req = $link->prepare("INSERT INTO requisites (courseID, prereq, coreq) VALUES ('$courseID', '$prereq', '$coreq')");
    $req->bind_param("sss", $prereq, $courseID, $coreq);
    $req->execute();

        header('Location: prereqCoreq');

   // close connection
    mysqli_close($link);
    ?>
