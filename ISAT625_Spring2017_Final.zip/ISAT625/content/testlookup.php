<?php
     mysql_connect("localhost", "ISAT625", "selu2017") or die("Error connecting to database: ".mysql_error());
         mysql_select_db("ISAT625") or die(mysql_error());
?>


<?php
    $query1 = $_POST['courseID'];
    $query2 = $_POST['wNumber'];



    // gets value sent over search form
    $min_length = 3;
    // you can set minimum length of the query if you want
    if(strlen($query1) >= $min_length){ // if query length is more or equal minimum length then
        $query1 = htmlspecialchars($query1);
        // changes characters used in html to their equivalents, for example: < to &gt;
        $query1 = mysql_real_escape_string($query1);
        // makes sure nobody uses SQL injection
        $raw_results = mysql_query("SELECT * FROM requisites WHERE courseID = '$query1' order by prereq") or die(mysql_error());
        $raw_results2 = mysql_query("SELECT * FROM courseHistory WHERE wNumber = '$query2' order by courseID") or die(mysql_error());
        if(mysql_num_rows($raw_results) > 0){ // if one or more rows are returned do following
            while($results = mysql_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
          //      echo "<p>course: ".$results['courseID']." has ".$results['prereq']." as a prereq.</p>";
                $coursePrereqs[$results['courseID']][]=$results['prereq'];
                print_r($coursePrereqs);

                // posts results gotten from database
            }
        }
        else{ // if there is no matching rows do following
            echo "No results";
        }
    }
    else{ // if query length is less than minimum
        echo "Minimum length is ".$min_length;
    }

    if(mysql_num_rows($raw_results2) > 0){ // if one or more rows are returned do following
        while($results2 = mysql_fetch_array($raw_results2)){
        // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
          //  echo "<p>Student: ".$results2['wNumber']." has ".$results2['courseID']." in their course history.</p>";
            $studenthist[$results2['wNumber']][]=$results2['courseID'];
            print_r($studenthist);
            // posts results gotten from database
        }
    }
    else{ // if there is no matching rows do following
        echo "No results";
}
