<!doctype html>
<html>
	<head>
		<title>Delete User Data</title>
	</head>

	<?php
	$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

	// Check connection
	if($link === false){
	    die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	$reqLookup = $link->query("select id,courseid,prereq from requisites order by courseid");
?>


<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Remove a requisite.</title>
	<link rel="stylesheet" type="text/css" href="subpages.css" />
</head>

<body>

	<form action="deletereq.php" method="post">
			<p>
					<label for="reqid">Which requisite would you like to remove from which course?</label><br />
					<select name="reqid" id="reqid">
						<option label=" "></option>
								<?php
								while ($row = $reqLookup->fetch_assoc()) {

																unset($req,$reqid,$courseid);
																$req = $row['prereq'];
																$reqid = $row['id'];
																$courseid = $row['courseid'];
																echo '<option value="'.$reqid.'">Remove '.$req.' as a requisite of '.$courseid.'</option>';
							}

							?>
								</select>
			</p>

<input type="submit" value="Submit" />
</form>

   </body>
   </html>
