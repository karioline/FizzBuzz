<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


    $courseLookup = $link->query("select distinct courseID from courses order by courseID");
    $studentLookup = $link->query("select wNumber,studentName from students order by studentName");
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add To Student's Course History</title>
    <link rel="stylesheet" type="text/css" href="subpages.css" />
</head>

<body>

    <form action="insertcoursehistory.php" method="post">
        <p>
            <label for="wNumber">Student:</label><br />
            <select name="wNumber" id="wNumber">
              <option label=" "></option>
                  <?php
                  while ($row = $studentLookup->fetch_assoc()) {

                                  unset($wNumber,$studentName);
                                  $wNumber = $row['wNumber'];
                                  $studentName = $row['studentName'];
                                  echo '<option value="'.$wNumber.'">'.$wNumber.' - '.$studentName.'</option>';
                }

                ?>
                  </select>
        </p>

          <p>
            <label for="courseID">Course ID:</label><br />
            <select name="courseID" id="courseID">
              <option label=" "></option>
                  <?php
                  while ($row = $courseLookup->fetch_assoc()) {

                                  unset($courseID);
                                  $courseID = $row['courseID'];
                                  echo '<option value="'.$courseID.'">'.$courseID.'</option>';
                }

                ?>
                  </select>
        </p>



        <p>
            <label for="grade">Grade:</label><br />
            <select name="grade" id="grade">
              <option value="A">A</option>
              <option value="B">B</option>
              <option value="C">C</option>
	      <option value="D">D</option>
		<option value="F">F</option>
            </select>
        </p>
        <input type="submit" value="Submit">

    </form>

</body>
</html>
