<?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

        if($link == false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    $courseid = mysqli_real_escape_string($link, $_REQUEST['courseid']);

    // attempt insert query execution
    $sql = "DELETE FROM students where courseid='$courseid'";

    if(mysqli_query($link, $sql)){
        header('Location: removecourse.php');
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   // close connection
    mysqli_close($link);
    ?>
