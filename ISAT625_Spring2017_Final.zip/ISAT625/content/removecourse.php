<!doctype html>
<html>
	<head>
		<title>Delete Course Data</title>
	</head>

	<?php
	$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

	// Check connection
	if($link === false){
	    die("ERROR: Could not connect. " . mysqli_connect_error());
	}
		$classLookup = $link->query("select classid from courses order by classid");
		$courseLookup = $link->query("select distinct courseid from courses order by courseid");
	?>


	<html lang="en">
	<head>
	    <meta charset="UTF-8">
	    <title>Delete Courses and Sections.</title>
	    <link rel="stylesheet" type="text/css" href="subpages.css" />
	</head>

	<body>

	    <form action="deleteclass.php" method="post">
	        <p>
	            <label for="classid">Which section of a course would you like to remove?</label><br />
	            <select name="classid" id="classid">
								<option label=" "></option>
	                  <?php
	                  while ($row = $classLookup->fetch_assoc()) {

	                                  unset($classid);
	                                  $classid = $row['classid'];
	                                  echo '<option value="'.$classid.'">'.$classid.'</option>';
	                }

	                ?>
	                  </select>
 </p>
 <input type="submit" value="Submit" />
</form>



	    <form action="deletecourse.php" method="post">
	        <p>
	            <label for="courseid">Would you like to remove all instances of a specific course?</label><br />
	            <select name="courseid" id="courseid">
								<option label=" "></option>
	                  <?php
	                  while ($row1 = $courseLookup->fetch_assoc()) {

	                                  unset($courseid);
	                                  $courseid = $row1['courseid'];
	                                  echo '<option value="'.$courseid.'">'.$courseid.'</option>';
	                }

	                ?>
	                  </select>
 </p>

<input type="submit" value="Submit" />
</form>
   </body>
   </html>
