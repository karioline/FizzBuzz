    <?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $studentName = mysqli_real_escape_string($link, $_REQUEST['studentName']);
    $wNumber = mysqli_real_escape_string($link, $_REQUEST['wNumber']);
    $studentEmail = mysqli_real_escape_string($link, $_REQUEST['studentEmail']);
    $concentration = $_REQUEST['concentration'];

    // attempt insert query execution
    $sql = "INSERT INTO students (studentName, wNumber, studentEmail, concentration) VALUES ('$studentName', '$wNumber', '$studentEmail', '$concentration')";
    if(mysqli_query($link, $sql)){
        header('Location: addstudent.php');
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   // close connection
    mysqli_close($link);
    ?>
