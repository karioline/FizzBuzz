<?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

        if($link == false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    $username = mysqli_real_escape_string($link, $_REQUEST['username']);

    // attempt insert query execution
    $sql = "DELETE FROM fgusers3 where username = '$username'";

    if(mysqli_query($link, $sql)){
        header('Location: removeuser.php');
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   // close connection
    mysqli_close($link);
    ?>
