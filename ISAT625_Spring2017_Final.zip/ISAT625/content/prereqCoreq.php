<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


    $result = $link->query("select distinct courseID from courses order by courseID");
    $result2 = $link->query("select distinct courseID from courses order by courseID");
    $result3 = $link->query("select distinct courseID from courses order by courseID");
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add a prerequisite or corequisite to an existing course.</title>
    <link rel="stylesheet" type="text/css" href="subpages.css" />
</head>

<body>

    <form action="insertrequisites.php" method="post">
        <p>
            <label for="courseID">Which course would you like to add a requisite to?<label><br />
            <select name="courseID" id="courseID">
            <option label=" "></option>
            <?php
            while ($row = $result->fetch_assoc()) {

                            unset($courseID);
                            $courseID = $row['courseID'];
                            echo '<option value="'.$courseID.'">'.$courseID.'</option>';
          }

          ?>
            </select>
        </p>




        <p>
            <label for="prereq">Which course is a prerequisite of your course?</label><br />
            <select name="prereq" id="prereq">
            <option label=" "></option>
            <?php
            while ($row = $result2->fetch_assoc()) {

                            unset($prereqID);
                            $prereqID = $row['courseID'];
                            echo '<option value="'.$prereqID.'">'.$prereqID.'</option>';
          }

          ?>
            </select>
        </p>

        <p>
            <label for="coreq">Which course is a corequisite of your course?</label><br />
            <select name="coreq" id="coreq">
            <option label=" "></option>
            <?php
            while ($row = $result3->fetch_assoc()) {

                            unset($coreqID);
                            $coreqID = $row['courseID'];
                            echo '<option value="'.$coreqID.'">'.$coreqID.'</option>';
          }

          ?>
            </select>
        </p>



        <input type="submit" value="Submit">

    </form>

</body>
</html>
