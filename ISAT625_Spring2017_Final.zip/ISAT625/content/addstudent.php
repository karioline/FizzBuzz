<!DOCTYPE html>



<?php
$link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


    $result = $link->query("select studentName from students order by studentName");
?>



<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="subpages.css" />
    <title>Add / Update Student Records</title>
</head>

<body>

    <form action="insertstudent.php" method="post">
        <p>
            <label for="studentName">Student Name:</label><br />
            <input type="text" name="studentName" id="studentName">
        </p>

        <p>
            <label for="wNumber">wNumber:</label><br />
            <input type="text" name="wNumber" id="wNumber">
        </p>

        <p>
            <label for="studentEmail">Email Address:</label><br />
            <input type="text" name="studentEmail" id="studentEmail">
        </p>
        <p>
            <label for="concentration">Concentration:</label><br />
            <select name="concentration" id="concentration">
              <option value="None Chosen">None Chosen</option>
              <option value="Scientific">Scientific</option>
              <option value="Pre-MBA">Pre-MBA</option>
        <option value="Engineering">Engineering</option>
        <option value="Industrial Technology">Industrial Technology</option>
            </select>
        </p>

        <input type="submit" value="Submit">
    </form>


</body>
</html>
