<?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

        if($link == false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    $classid = mysqli_real_escape_string($link, $_REQUEST['classid']);

    // attempt insert query execution
    $sql = "DELETE FROM courses where classid='$classid'";

    if(mysqli_query($link, $sql)){
        header('Location: removecourse.php');
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   // close connection
    mysqli_close($link);
    ?>
