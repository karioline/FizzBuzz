    <?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $name = mysqli_real_escape_string($link, $_REQUEST['name']);
    $securityLevel = $_REQUEST['securityLevel'];

    // attempt insert query execution
    $sql = "UPDATE fgusers3 set securityLevel='$securityLevel' where name='$name'";
    if(mysqli_query($link, $sql)){
        header('Location: security.php');
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   // close connection
    mysqli_close($link);
    ?>
