<?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

        if($link == false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    $wNumber = mysqli_real_escape_string($link, $_REQUEST['wNumber']);

    // attempt insert query execution
    $sql = "DELETE FROM students where wNumber='$wNumber'";

    if(mysqli_query($link, $sql)){
        header('Location: removestudent.php');
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   // close connection
    mysqli_close($link);
    ?>
