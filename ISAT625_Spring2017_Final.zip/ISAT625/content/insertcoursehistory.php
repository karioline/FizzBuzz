    <?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $courseID = $_REQUEST['courseID'];
    $wNumber = $_REQUEST['wNumber'];
    $grade = $_REQUEST['grade'];

    // prepare and bind

    $req = $link->prepare("INSERT INTO courseHistory (courseID, wNumber, grade) VALUES ('$courseID', '$wNumber', '$grade')");
    $req->bind_param("sis", $courseID, $wNumber, $grade);
    $req->execute();

        header('Location: studentcoursehistory.php');

   // close connection
    mysqli_close($link);
    ?>
