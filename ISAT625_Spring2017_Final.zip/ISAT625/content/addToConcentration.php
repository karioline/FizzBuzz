    <?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $wNumber = $_REQUEST['wNumber'];
    $concentration = $_REQUEST['concentration'];

    // attempt insert query execution
    $sql = "UPDATE students SET concentration = '$concentration' where wNumber = '$wNumber'";

    if(mysqli_query($link, $sql)){
        header('Location: changeconcentration.php');
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   // close connection
    mysqli_close($link);
    ?>
