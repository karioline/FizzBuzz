    <?php
    $link = mysqli_connect("localhost", "ISAT625", "selu2017", "ISAT625");

    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $courseID = $_REQUEST['courseID'];
    $courseName = $_REQUEST['courseName'];
    $hours = $_REQUEST['hours'];
    $hasPrereq = $_REQUEST['hasPrereq'];
    $subject = substr ($courseID, 0, 4);
    $courseNum = substr ($courseID, 4);
    $prereqOf = $_REQUEST['prereqOf'];
    $coreqOf = $_REQUEST['coreqOf'];
    $sections = $_REQUEST['sections'];
    $dephead - $_REQUEST['dephead'];
    // prepare and bind
  //  $req = $link->prepare("INSERT INTO requisites (courseID, prereq, coreq, dephead) VALUES ('$prereqOf', '$courseID', '$coreq', '$dephead')");
  //  $req->bind_param("ssss", $prereqOf, $courseID, $coreqOf, $dephead);
  //  $req->execute();

for ($x = 1; $x <= $sections; $x++) {
    $classID = $courseID . "-0" . $x;
    $sql = $link->prepare("INSERT INTO courses (courseID, courseName, hours, hasPrereq, subject, courseNum, classID) VALUES ('$courseID', '$courseName', '$hours', '$hasPrereq', '$subject', '$courseNum', '$classID')");
    $sql->bind_param("ssissis", $courseID, $courseName, $hours, $hasPrereq, $subject, $courseNum, $classID);
    $sql->execute();
}

        header('Location: course.php');

   // close connection
    mysqli_close($link);
    ?>
